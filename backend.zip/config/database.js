const mysql = require("mysql2");

const conn = mysql.createPool({
    host : ,
    port : ,
    user : ,
    password : ,
    database : 
});

conn.getConnection((err) => {
    if (err) {
      console.error('DB 연결 실패:', err.message);
      return;
    }
    console.log('DB 연결 성공');
  });

module.exports = conn;