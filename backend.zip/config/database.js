const mysql = require("mysql2");

const conn = mysql.createPool({
    host : "project-db-cgi.smhrd.com",
    port : 3307,
    user : "campus_24IS_IOT2_p2_2",
    password : "smhrd2",
    database : "campus_24IS_IOT2_p2_2"
});

conn.getConnection((err) => {
    if (err) {
      console.error('DB 연결 실패:', err.message);
      return;
    }
    console.log('DB 연결 성공');
  });

module.exports = conn;