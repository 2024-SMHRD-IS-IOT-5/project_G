const express = require("express");
const app = express();
// const axios = require("axios")

const bp = require("body-parser");
app.use(bp.json());
app.use(bp.urlencoded({ extended : true }));
app.use(express.json());

const path = require('path');
app.use(express.static(path.join(__dirname, "..", "frontend", "build")));
app.use(express.json());

const cors = require('cors');
app.use(cors());

const Login = require("./routes/login");
app.use("/", Login);


const Insert = require("./routes/insertdata");
app.use("/insert", Insert);

const Select = require("./routes/selectdata")
app.use("/select", Select)

// const Esp32Control = require("./routes/esp32control");
// app.use("/req", Esp32Control);

app.set("port", process.env.PORT || 8000);
app.listen(app.get("port"), () => {
    console.log(`Server is running on ${app.get("port")}`);
});