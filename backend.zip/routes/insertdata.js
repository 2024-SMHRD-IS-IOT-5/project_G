const express = require("express")
const router = express.Router();
const conn = require("../config/database")

router.post('/led', (req, res) => {
  const {
    ess_energy,
    kep_power_meter,
    led_power
  } = req.body;
  console.log(req.body);


  // ess 베터리 전력 저장량
  // const Ess = "INSERT INTO t_ess (ess_type, ess_energy) VALUES (?, ?)";
  // conn.query(Ess, [ess_type, ess_energy], (err, results) => {
  //   if (err) {
  //     console.error("Error inserting data: ", err);
  //     return res.status(500).json({ status: "error", message: "Database insertion failed" });
  //   }
  //   console.log("Data inserted successfully: ", results);
  // });


  // 한전 전력 공급량
  // const kep_power = "INSERT INTO t_kep_power (kep_power_meter) VALUES (?)";
  // conn.query(kep_power, [kep_power_meter], (err, results)=> {
  //   if (err) {
  //     console.error("Error inserting data: ", err);
  //     return res.status(500).json({ status: "error", message: "Database insertion failed" });
  //   }
  //   console.log("Data inserted successfully: ", results);
  // });


  // LED 전력 소모량
  const led_meter = "INSERT INTO t_led_power (led_power) VALUES (?)";
  conn.query(led_meter, [led_power], (err, results) => {
    if (err) {
      console.error("Error inserting data: ", err);
      return res.status(500).json({ status: "error", message: "Database insertion failed" });
    }
    console.log("Data inserted successfully: ", results);
  });
  // ESP32로 응답
  res.json({ status: "success", message: "Data received and stored in DB" });
});


// 실링팬,온습도 데이터 받는 경로
router.post("/else", (req, res) => {
  const {
    indoor_temp,
    indoor_humid,
    fan_power
  } = req.body;
  console.log(req.body);


  // fan 전력 소모량
  const fan_meter = "INSERT INTO t_fan_power (fan_power) VALUES (?)";
  conn.query(fan_meter, [fan_power], (err, results) => {
    if (err) {
      console.error("Error inserting data: ", err);
      return res.status(500).json({ status: "error", message: "Database insertion failed" });
    }
    console.log("Data inserted successfully: ", results);
  });


  // 내부 온습도
  const indoor = `INSERT INTO t_indoor_weather
                          (indoor_temp, indoor_humid) VALUES (?, ?)`;
  conn.query(indoor, [indoor_temp, indoor_humid], (err, results) => {
    if (err) {
      console.error("Error inserting data: ", err);
      return res.status(500).json({ status: "error", message: "Database insertion failed" });
    }
    console.log("Data inserted successfully: ", results);
  });
  // ESP32로 응답
  res.json({ status: "success", message: "Data received and stored in DB" });
});


// 재생 에너지 타입(풍력,태양광)과 전력 생산량
router.post("/renew", (req, res) => {
  const {
    solar_power,
    wind_power
  } = req.body;
  console.log(req.body);

  const re_power = "INSERT INTO t_re_power (solar_power, wind_power) VALUES (?, ?)";
  conn.query(re_power, [solar_power, wind_power], (err, results) => {
    if (err) {
      console.error("Error inserting data: ", err);
      return res.status(500).json({ status: "error", message: "Database insertion failed" });
    }
    console.log("Data inserted successfully: ", results);
  });
  // ESP32로 응답
  res.json({ status: "success", message: "Data received and stored in DB" });
});

module.exports = router;