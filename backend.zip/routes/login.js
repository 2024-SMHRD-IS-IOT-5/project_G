const express = require("express");
const router = express.Router();
const conn = require("../config/database")

router.get("/", (req, res) => {
    console.log("main");
    res.sendFile(path.join(__dirname, '..', '..', 'frontend', 'build', 'index.html'))
})

router.post('/login', (req, res) => {
    let {admin_id, admin_pw} = req.body;
    let sql = "select * from t_admin where admin_id = ? and admin_pw = ?"
    conn.query(sql, [admin_id, admin_pw], (err, rows) => {
        if (err) {
            console.error("Database query error:", err);
            return res.status(500).send("서버 오류");
        }
        
        if (rows.length > 0) { // 로그인 성공
            console.log("로그인 성공:", rows[0]);
            res.status(200).send({ message: "success" });
        } else { // 로그인 실패
            console.log("로그인 실패");
            res.status(401).send({ message: "failed" });
        }
    });
});

module.exports = router;