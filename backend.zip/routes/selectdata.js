const express = require("express")
const router = express.Router();
const conn = require("../config/database")

router.get("/indoor", (req, res) => {
    const indoor = "select indoor_floor, indoor_temp, indoor_humid from t_indoor_weather";
    conn.query(indoor, (err, rows) => {
        console.log(rows[0]);
        if (err) {
            console.error("Database query error: ", err);
            return res.status(500).send("서버 오류");
        } else {
            res.json(rows);
        }
    });
});

router.get("/comp", (req, res) => {
    const consumption = "select comp_dt, comp_power from t_consumption";
    conn.query(consumption, (err, rows) => {
        // console.log(rows[0]);
        if (err) {
            console.error("Database query error: ", err);
            return res.status(500).send("서버 오류");
        } else {
            res.json(rows);
        }
    });
});


router.get("/ess", (req, res) => {
    const ess = "select ess_energy from t_ess";
    conn.query(ess, (err, rows) => {
        // console.log(rows[0]);
        if (err) {
            console.error("Database query error: ", err);
            return res.status(500).send("서버 오류");
        } else {
            res.json(rows);
        }
    });
});

router.get("/kep", (req, res) => {
    const kep_power = "select kep_power_meter from t_kep_power";
    conn.query(kep_power, (err, rows) => {
        // console.log(rows[0]);
        if (err) {
            console.error("Database query error: ", err);
            return res.status(500).send("서버 오류");
        } else {
            res.json(rows);
        }
    });
});

router.get("/re", (req, res) => {
    const re_power = "select solar_power, wind_power from t_re_power";
    conn.query(re_power, (err, rows) => {
        // console.log(rows[0]);
        if (err) {
            console.error("Database query error: ", err);
            return res.status(500).send("서버 오류");
        } else {
            res.json(rows);
        }
    });
});

// router.get("/fan", (req,res) => {
//     const fan_power = "select fan_power from t_fan_power"
//     conn.query(fan_power, (err, rows) =>{
//         if (err) {
//             console.error("Database query error: ", err);
//             return res.statys(500).send("서버 오류");
//         } else {
//             res.json(rows)
//         }
//     });
// });


module.exports = router;