// const express = require("express");
// const router = express.Router();


// const esp32Ip = "";

// router.post("/control", async (req, res) => {
//   const { command } = req.body;

//   if (!command) {
//     return res.status(400).json({ message: "Invalid command" });
//   }

//   try {
//     // ESP32로 HTTP 요청 전송
//     const response = await axios.post(`http://${esp32Ip}/control`, { command });
//     res.json({ message: "Command sent to ESP32", espResponse: response.data });
//   } catch (error) {
//     console.error("Error communicating with ESP32:", error.message);
//     res.status(500).json({ message: "Failed to send command to ESP32" });
//   }
// });

// module.exports = router;