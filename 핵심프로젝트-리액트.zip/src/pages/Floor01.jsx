import React, { useEffect, useState } from 'react';
import '../style/HomePage.css';
import { BsLightbulb, BsLightbulbFill, BsFan, BsWindow, BsWindowSidebar } from 'react-icons/bs';
import ReactECharts from 'echarts-for-react';
import axios from 'axios';
import SwitchButton from "../components/SwitchButton";
import '../style/SwitchButton.css';

const Floor01 = () => {
    const baseURL = "IP주소"; // 아두이노 IP 주소

    const [usageData, setUsageData] = useState([]); // 사용 전력량
    const [temperatureData, setTemperatureData] = useState({ floors: [], temp: [], humid: [] }); // 층별 온도/습도

    const [isToggled1, setIsToggled1] = useState(false); // LED 제어 버튼
    const [isToggled2, setIsToggled2] = useState(false); // 실링팬 제어 버튼
    const [isToggled3, setIsToggled3] = useState(false); // 창문 제어 버튼

    useEffect(() => {
        const temperatureData = async () => {
            try {
                const response = await axios.get("ip 주소"); // ip 주소 입력
                const floors = response.data.map(item => item.indoor_floor); // 층수
                const temp = response.data.map(item => item.indoor_temp); // 실내 온도
                const humid = response.data.map(item => item.indoor_humid); // 실내 습도
                setTemperatureData({ floors, temp, humid });
            } catch (error) {
                console.error("온도/습도 에러났어요", error);
            }
        };

        const UsageData = async () => {
            try {
                const response = await axios.get("ip 주소"); // ip 주소 입력
                setUsageData(response.data);
            } catch (error) {
                console.error("전력 사용 에러났어요", error);
            }
        };

        UsageData();
        temperatureData();
    }, []);

    //  아두이노 - 리액트 연결 -> 제어 
    
    const toggleLED = async (isOn) => {
        try {
            const endpoint = isOn ? "/control/led/on" : "/control/led/off";
            const response = await axios.get(`${baseURL}${endpoint}`);
            console.log(response.data);
            setIsToggled1(isOn); // React 상태 업데이트
        } catch (error) {
            console.error("LED 제어 에러:", error);
        }
    };

    const toggleFan = async (isOn) => {
        try {
            const endpoint = isOn ? "/control/fan/on" : "/control/fan/off";
            const response = await axios.get(`${baseURL}${endpoint}`);
            console.log(response.data);
            setIsToggled2(isOn);
        } catch (error) {
            console.error("팬 에러났어요", error);
        }
    };

    const toggleWindow = async (isOpen) => {
        try {
            const endpoint = isOpen ? "/control/window/open" : "/control/window/closed";
            const response = await axios.get(`${baseURL}/${endpoint}`);
            console.log(response.data);
            setIsToggled3(isOpen);
        } catch (error) {
            console.error("창문 에러났어요", error);
        }
    };

    const usageChartOptions = {
        title: { text: '', left: 'center' },
        xAxis: { type: 'category', data: ['00시', '03시', '06시', '09시', '12시', '15시', '18시', '21시'] },
        yAxis: { type: 'value' },
        series: [{ data: [120, 200, 150, 80, 70, 300, 340, 120], type: 'bar', color: 'blue' }],
    };

    const FloortemperatureChartOptions1F = {
        title: { text: '', left: 'center' },
        legend: {
            data: ['온도', '습도'],
            top: 'bottom',
            textStyle: { fontSize: 12, color: 'black' },
        },
        xAxis: { type: 'category', data: ['00시', '03시', '06시', '09시', '12시', '15시', '18시', '21시'] },
        yAxis: { type: 'value' },
        series: [
            { name: '온도', data: [13, 9, 11, 16, 22, 24, 20, 18], type: 'line', color: 'orange' },
            { name: '습도', data: [60, 55, 60, 45, 50, 55, 50, 40], type: 'line', color: 'skyblue' },
        ],
    };

    return (
        <div className="home-dashboard">
            {/* Row 1 */}
            <div className="row">
                <div className="home-item">
                    1F 전력 사용량
                    <div className="chart-container">
                        <ReactECharts
                            option={usageChartOptions}
                            style={{ height: '200px', width: '100%' }} />
                    </div>
                </div>
                <div className="home-item">
                1F 실내 등
                    {/* 실내 등 확인 */}
                    <div className="floor-container">
                        <div className="floor-card">
                            <div className="row">
                                <div className="floor-item">
                                    {/* LED 상태를 조건부로 렌더링 */}
                                    {isToggled1 ? (
                                        <div>
                                            <BsLightbulbFill size={36} color="black" />
                                            <p>Led On</p>
                                        </div>
                                    )
                                        : (
                                            <div>
                                                <BsLightbulb size={36} color="black" />
                                                <p>Led Off</p>
                                            </div>
                                        )}
                                </div>
                                <div className="floor-item">
                                    <br />
                                    {/* 실내 등 제어 */}
                                    <SwitchButton
                                        isChecked={isToggled1}
                                        onChange={() => setIsToggled1(!isToggled1)}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Row 2 */}
            <div className="row">
                <div className="home-item">
                    1F 온도, 습도
                    <div className="chart-container">
                        <ReactECharts
                            option={FloortemperatureChartOptions1F}
                            style={{ height: '200px', width: '100%' }}
                        />
                    </div>
                </div>
                <div className="home-item">
                1F 실링팬/창문
                    <div className="floor-container">
                        <div className="floor-card">
                            <div className="row">
                                <div className="floor-item">
                                    {/* 실링팬 상태를 조건부로 렌더링 */}
                                    {isToggled2 ? (
                                        <div>
                                            {/* 돌아가는 팬  */}
                                            <div className="rotating">
                                                <BsFan size={48} color="black" />
                                            </div>
                                            <p>Fan On</p>
                                        </div>
                                    ) : (
                                        <div>
                                            {/* 멈춰있는 팬 */}
                                            <BsFan size={48} color="black" />
                                            <p>Fan Off</p>
                                        </div>
                                    )}
                                </div>
                                <div className="floor-item">
                                    <br />
                                    <SwitchButton
                                        isChecked={isToggled2}
                                        onChange={() => setIsToggled2(!isToggled2)}
                                    />
                                </div>
                            </div>
                            <div className="floor-container">
                                <div className="floor-card">
                                    <div className="row">
                                        <div className="floor-item">
                                            <div>
                                                {/* 창문 상태를 조건부로 렌더링 */}
                                                {isToggled3 ? (
                                                    <div>
                                                        <BsWindow size={36} color="black" />
                                                        <p>Window Open</p>
                                                    </div>
                                                ) : (
                                                    <div>
                                                        <BsWindowSidebar size={36} color="black" />
                                                        <p>Window Closed</p>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                        <div className="floor-item">
                                            <br />
                                            {/* 창문 제어 */}
                                            <SwitchButton
                                                isChecked={isToggled3}
                                                onChange={() => setIsToggled3(!isToggled3)}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Floor01;
