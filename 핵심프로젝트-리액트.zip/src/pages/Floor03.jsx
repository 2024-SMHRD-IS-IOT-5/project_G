import React, { useEffect, useState } from 'react'
import '../style/HomePage.css'
import { BsLightbulb, BsLightbulbFill, BsMapFill, BsMap, BsFan, BsWindow, BsWindowSidebar } from 'react-icons/bs';
import { MdFan } from 'react-icons/md';
import '../style/CeilingFan.css';
import ReactECharts from 'echarts-for-react';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import SwitchButton from "../components/SwitchButton";
import '../style/SwitchButton.css';

const Floor03 = () => {

    const [usageData, setUsageData] = useState([]); // 사용 전력량
    const [temperatureData, setTemperatureData] = useState({ floors: [], temp: [], humid: [] }); // 층별 온도/습도

    const [isToggled1, setIsToggled1] = useState(false); // 등 제어 버튼
    const [isToggled2, setIsToggled2] = useState(false); // 실링팬 제어 버튼
    const [isToggled3, setIsToggled3] = useState(false); // 창문 제어 버튼

    const [isFanOn, setIsFanOn] = useState(false); // 팬 상태
    const [isWindowOpen, setIsWindowOpen] = useState(false); // 창문 상태

    useEffect(()=>{
        const temperatureData = async () => {
            try {
                const response = await axios.get("ip 주소"); // ip 주소 입력
                const floors = response.data.map(item => item.indoor_floor); // 층수
                const temp = response.data.map(item => item.indoor_temp); // 실내 온도
                const humid = response.data.map(item => item.indoor_humid); // 실내 습도
                setTemperatureData({ floors, temp, humid });
            } catch (error) {
                console.error("에러났어요", error);
            }
        };

        const UsageData = async () => {
            try {
                const response = await axios.get("ip 주소"); // ip 주소 입력
                setUsageData(response.data);
            } catch (error) {
                console.error("에러났어요", error);
            }
        };

        UsageData();
        temperatureData();
    },[])

    const usageChartOptions = {
        title: { text: '', left: 'center' },
        xAxis: { type: 'category', data: ['00시', '03시', '06시', '09시', '12시', '15시', '18시', '21시'] },
        yAxis: { type: 'value' },
        series: [{ data: [120, 200, 150, 80, 70, 300, 340, 120], type: 'bar', color: 'blue' }],
    };

    const FloortemperatureChartOptions3F = {
        title: { text: '', left: 'center' },
        legend: {
            data: ['온도', '습도'], // 범례에 표시할 시리즈 이름
            top: 'bottom', // 범례 위치
            textStyle: {
                fontSize: 12, // 범례 글자 크기
                color: 'black', // 범례 텍스트 색상
            },
        },
        xAxis: { type: 'category', data: ['00시', '03시', '06시', '09시', '12시', '15시', '18시', '21시'] },
        yAxis: { type: 'value' },
        series: [
            { name: '온도', data: [10, 8, 15, 20, 22, 26, 18, 9], type: 'line', color: 'orange' },
            { name: '습도', data: [40, 55, 60, 45, 50, 31, 20, 45], type: 'line', color: 'skyblue' },
        ],
    };


    return (
        <div className="home-dashboard">
            {/* Row 1 */}
            <div className="row">
                <div className="home-item">
                    3F 전력 사용량
                    {/* 사용 전력량 */}
                    <div className="chart-container">
                        <ReactECharts
                            option={usageChartOptions}
                            style={{ height: '200px', width: '100%' }} />
                    </div>
                </div>
                <div className="home-item">
                    3F 실내 등
                    {/* 실내 등 확인 */}
                    <div className="floor-container">
                        <div className="floor-card">
                            <div className="row">
                                <div className="floor-item">
                                    {/* LED 상태를 조건부로 렌더링 */}
                                    {isToggled1 ? (
                                        <div>
                                            <BsLightbulbFill size={36} color="black" />
                                            <p>Led On</p>
                                        </div>
                                    )
                                        : (
                                            <div>
                                                <BsLightbulb size={36} color="black" />
                                                <p>Led Off</p>
                                            </div>
                                        )}
                                </div>
                                <div className="floor-item">
                                    <br />
                                    {/* 실내 등 제어 */}
                                    <SwitchButton
                                        isChecked={isToggled1}
                                        onChange={() => setIsToggled1(!isToggled1)}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* Row 2 */}
            <div className="row">
                <div className="home-item">
                    3F 온도, 습도
                    {/* 온도, 습도 확인 */}
                    <div className="chart-container">
                        <ReactECharts
                            option={FloortemperatureChartOptions3F}
                            style={{ height: '200px', width: '100%' }}
                        />
                    </div>
                </div>
                <div className="home-item">
                    3F 실링팬/창문
                    <div className="floor-container">
                        <div className="floor-card">
                            <div className="row">
                                <div className="floor-item">
                                    {/* 실링팬 상태를 조건부로 렌더링 */}
                                    {isToggled2 ? (
                                        <div>
                                            {/* 돌아가는 팬  */}
                                            <div className="rotating">
                                                <BsFan size={48} color="black" />
                                            </div>
                                            <p>Fan On</p>
                                        </div>
                                    ) : (
                                        <div>
                                            {/* 멈춰있는 팬 */}
                                            <BsFan size={48} color="black" />
                                            <p>Fan Off</p>
                                        </div>
                                    )}
                                </div>
                                <div className="floor-item">
                                    <br />
                                    <SwitchButton
                                        isChecked={isToggled2}
                                        onChange={() => setIsToggled2(!isToggled2)}
                                    />
                                </div>
                            </div>
                            <div className="floor-container">
                                <div className="floor-card">
                                    <div className="row">
                                        <div className="floor-item">
                                            <div>
                                                {/* 창문 상태를 조건부로 렌더링 */}
                                                {isToggled3 ? (
                                                    <div>
                                                        <BsWindow size={36} color="black" />
                                                        <p>Window Open</p>
                                                    </div>
                                                ) : (
                                                    <div>
                                                        <BsWindowSidebar size={36} color="black" />
                                                        <p>Window Closed</p>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                        <div className="floor-item">
                                            <br />
                                            {/* 창문 제어 */}
                                            <SwitchButton
                                                isChecked={isToggled3}
                                                onChange={() => setIsToggled3(!isToggled3)}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Floor03
