import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './components/LoginPage.jsx'; // Login.jsx 경로
import HomePage from './components/HomePage.jsx'; // HomePage.jsx 경로
import SwitchButton from './components/SwitchButton.jsx'; // button 경로
import { TimerProvider } from './context/TimerContext.js'; // TimerProvider 경로
import './App.css';

const App = () => {
  return (

    <Router>
      <TimerProvider>
        <Routes>
          {/* 로그인 페이지 라우팅 */}
          <Route path="/" element={<LoginPage />} />

          {/* 관리자 페이지 라우팅 */}
          <Route path="/home" element={<HomePage />} />
        </Routes>
      </TimerProvider>
    </Router >

  );
}

export default App;
