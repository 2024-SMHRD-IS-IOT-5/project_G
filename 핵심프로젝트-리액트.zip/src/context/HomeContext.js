import { createContext } from "react";

export const HomeContext = createContext(null)