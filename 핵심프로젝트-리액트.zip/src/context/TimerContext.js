import React, { createContext, useContext, useState, useEffect } from "react";

const TimerContext = createContext();

export const TimerProvider = ({ children }) => {
  const timeoutDuration = 30 * 60 * 1000; // 30분
  const alertDuration = 30 * 1000; // 30초 전 알림
  const [remainingTime, setRemainingTime] = useState(
    parseInt(localStorage.getItem("remainingTime"), 10) || timeoutDuration
  );
  const [timerId, setTimerId] = useState(null);
  const [alertShown, setAlertShown] = useState(false);

  const startTimer = () => {
    const startTime = Date.now();
    const endTime = startTime + remainingTime;
    localStorage.setItem("endTime", endTime);
    localStorage.setItem("remainingTime", remainingTime);

    const id = setInterval(() => {
      const now = Date.now();
      const timeLeft = endTime - now;

      if (timeLeft <= alertDuration && !alertShown) {
        setAlertShown(true);
        const extend = window.confirm("페이지가 곧 종료됩니다. 연장하시겠습니까?");
        if (extend) {
          extendSession();
        }
      }

      if (timeLeft <= 0) {
        clearInterval(id);
        // 로그아웃 처리는 Provider 외부에서 수행
        setRemainingTime(timeoutDuration);
        localStorage.removeItem("remainingTime");
        localStorage.removeItem("endTime");
      } else {
        setRemainingTime(timeLeft);
        localStorage.setItem("remainingTime", timeLeft);
      }
    }, 1000);

    setTimerId(id);
  };

  const extendSession = () => {
    setRemainingTime(timeoutDuration);
    setAlertShown(false);
    clearInterval(timerId);
    startTimer();
  };

  const stopTimer = () => {
    clearInterval(timerId);
    setRemainingTime(timeoutDuration);
    localStorage.removeItem("remainingTime");
    localStorage.removeItem("endTime");
  };

  useEffect(() => {
    const endTime = localStorage.getItem("endTime");
    if (endTime) {
      const timeLeft = parseInt(endTime, 10) - Date.now();
      if (timeLeft > 0) {
        setRemainingTime(timeLeft);
        startTimer();
      } else {
        stopTimer();
      }
    }
    return () => clearInterval(timerId); // 컴포넌트 언마운트 시 타이머 정리
  }, []);

  return (
    <TimerContext.Provider
      value={{
        remainingTime,
        startTimer,
        stopTimer,
      }}
    >
      {children}
    </TimerContext.Provider>
  );
};

export const useTimer = () => useContext(TimerContext);
