import React, { useEffect, useState } from "react";
import "../style/HomePage.css";
import logo from "../img/sng2.png";
import ReactECharts from 'echarts-for-react';
import axios from 'axios';
import SwitchButton from "./SwitchButton";
import '../style/SwitchButton.css';
import { useTimer } from "../context/TimerContext";
import { useNavigate } from "react-router-dom";
import {Floor01, Floor02, Floor03, Floor04, Floor05} from "../pages/Floorindex";


const HomePage = () => {
    const navigate = useNavigate(); // navigate 가져오기
    const { remainingTime, stopTimer } = useTimer();

    const [activeTab, setActiveTab] = useState("home"); // 초기 활성화 탭
    const [isFloorExpanded, setIsFloorExpanded] = useState(false); // Floor 버튼 확장
    const floors = ["1F", "2F", "3F", "4F", "5F"]; // 층 목록

    const [usageData, setUsageData] = useState([]); // 사용 전력량
    const [generationData, setGenerationData] = useState({ solar: [], wind: [] }); // 발전 전력량
    const [temperatureData, setTemperatureData] = useState({ floors: [], temp: [], humid: [] }); // 층별 온도/습도
    const [essData, setEssData] = useState([]); // 저장 전력량

    const [city, setCity] = useState("Gwangju"); // 기본값을 광주로 설정
    const [temp, setTemp] = useState(); // 섭씨 온도
    const [cloud, setCloud] = useState(); // 구름량
    const [humidity, setHumidity] = useState(); // 습도량
    const [windspeed, setWindSpeed] = useState(); // 바람의 속도
    const [windpower, setWindPower] = useState(); // 바람의 세기
    const [winddeg, setWindDeg] = useState(); // 바람의 방향



    const handleLogout = () => {
        stopTimer(); // 타이머 정리
        navigate("/"); // 로그인 페이지로 이동
    }

    // weather API
    useEffect(() => {
        const WeatherData = async () => {
            try {
                const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid={key}`; // key 부분에 api key값 입력
                const response = await axios.get(url);
                setTemp(parseInt(response.data.main.temp - 273));
                setHumidity(response.data.main.humidity);
                setWindSpeed(response.data.wind.speed);
                let direction = response.data.wind.deg;

                if (direction >= 348.75 || direction < 11.25) { setWindDeg("북 (N)"); }
                else if (direction >= 11.25 && direction < 33.75) { setWindDeg("북북동 (NNE)"); }
                else if (direction >= 33.75 && direction < 56.25) { setWindDeg("북동 (NE)"); }
                else if (direction >= 56.25 && direction < 78.75) { setWindDeg("동북동 (ENE)"); }
                else if (direction >= 78.75 && direction < 101.25) { setWindDeg("동 (E)"); }
                else if (direction >= 101.25 && direction < 123.75) { setWindDeg("동남동 (ESE)"); }
                else if (direction >= 123.75 && direction < 146.25) { setWindDeg("남동 (SE)"); }
                else if (direction >= 146.25 && direction < 168.75) { setWindDeg("남남동 (SSE)"); }
                else if (direction >= 168.75 && direction < 191.25) { setWindDeg("남 (S)"); }
                else if (direction >= 191.25 && direction < 213.75) { setWindDeg("남남서 (SSW)"); }
                else if (direction >= 213.75 && direction < 236.25) { setWindDeg("남서 (SW)"); }
                else if (direction >= 236.25 && direction < 258.75) { setWindDeg("서남서 (WSW)"); }
                else if (direction >= 258.75 && direction < 281.25) { setWindDeg("서 (W)"); }
                else if (direction >= 281.25 && direction < 303.75) { setWindDeg("서북서 (WNW)"); }
                else if (direction >= 303.75 && direction < 326.25) { setWindDeg("북서 (NW)"); }
                else if (direction >= 326.25 && direction < 348.75) { setWindDeg("북북서 (NNW)"); }

                const clouds = response.data.clouds.all;
                if (clouds > 90) setCloud("🌥매우 흐림");
                else if (clouds > 60) setCloud("⛅흐림");
                else if (clouds > 30) setCloud("🌤약간 흐림");
                else setCloud("🔆맑음");

                const wpower = response.data.wind.speed;
                if (wpower > 7) setWindPower("강풍");
                else if (wpower > 3) setWindPower("약풍");
                else if (wpower > 1) setWindPower("미풍");

            } catch (error) {
                console.error("에러났어요", error);
            }
        };

        const UsageData = async () => {
            try {
                const response = await axios.get("ip 주소"); // ip 주소 입력
                setUsageData(response.data);
            } catch (error) {
                console.error("에러났어요", error);
            }
        };

        const GenerationData = async () => {
            try {
                const response = await axios.get("ip 주소"); // ip 주소 입력
                const solar = response.data.filter(item => item.power_type === "태양광").map(item => item.power_meter);// 생산되는 전력
                const wind = response.data.filter(item => item.power_type === "풍력").map(item => item.power_meter);// 생산되는 전력
                setGenerationData({ solar, wind });
            } catch (error) {
                console.error("에러났어요", error);
            }
        };

        const TemperatureData = async () => {
            try {
                const response = await axios.get("ip 주소"); // ip 주소 입력
                const floors = response.data.map(item => item.indoor_floor); // 층수
                const temp = response.data.map(item => item.indoor_temp); // 실내 온도
                const humid = response.data.map(item => item.indoor_humid); // 실내 습도
                setTemperatureData({ floors, temp, humid });
            } catch (error) {
                console.error("에러났어요", error);
            }
        };


        const EssData = async () => {
            try {
                const response = await axios.get("ip 주소"); // ip 주소 입력
                setEssData(response.data);
            } catch (error) {
                console.error("에러났어요", error);
            }
        };

        WeatherData();
        UsageData();
        GenerationData();
        TemperatureData();
        EssData();

        // 10분마다 실시간으로 데이터를 가져옴 (600000ms = 600초, 약 10분)
        const interval = setInterval(() => {
            WeatherData();
        }, 600000);
        // 컴포넌트 언마운트 시 인터벌 정리
        return () => clearInterval(interval);
    }, [city]);

    // 사용 전력량 차트
    const usageChartOptions = {
        title: { text: '', left: 'center' },
        xAxis: { type: 'category', data: ['00시', '03시', '06시', '09시', '12시', '15시', '18시', '21시'] },
        yAxis: { type: 'value' },
        series: [{ data: usageData, type: 'bar', color: 'blue' }],
    };

    // 발전 전력량 차트
    const generationChartOptions = {
        title: { text: '발전 전력량', left: 'center' },
        legend: {
            data: ['태양광', '풍력'],
            top: 'bottom',
            textStyle: { fontSize: 12, color: 'black' },
        },
        xAxis: { type: 'category', data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] },
        yAxis: { type: 'value' },
        series: [
            { name: '태양광', data: generationData.solar, type: 'line', smooth: true, color: 'red' },
            { name: '풍력', data: generationData.wind, type: 'line', smooth: true, color: 'yellowgreen' },
        ],
    };

    // 전력 효율 차트
    const efficiencyChartOptions = {
        title: { text: '전력 효율(%)', left: 'center' },
        xAxis: { type: 'category', data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] },
        yAxis: { type: 'value' },
        series: [{ data: [80, 82, 88, 86, 82, 89, 91], type: 'line', color: 'blue' }], 
        // 90% 이상 : 매우 좋음 , 80-90% : 좋음, 70-80% : 보통, 70%미만 : 안좋음
    };

    // 온도, 습도 차트
    const temperatureChartOptions = {
        title: { text: '', left: 'center' },
        legend: {
            data: ['온도', '습도'],
            top: 'bottom',
            textStyle: { fontSize: 12, color: 'black' },
        },
        xAxis: { type: 'category', data: temperatureData.floors },
        yAxis: { type: 'value' },
        series: [
            { name: '온도', data: temperatureData.temp, type: 'line', color: 'orange' },
            { name: '습도', data: temperatureData.humid, type: 'line', color: 'skyblue' },
        ],
    };

    // 현재 저장된 전력량
    const essChartOptions = {
        title: { text: '현재 저장된 전력량', left: 'center' },
        xAxis: { type: 'category', data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] },
        yAxis: { type: 'value' },
        series: [{ data: essData, type: 'bar', smooth: true, color: 'blue' }],
    };

    return (
        // 홈 페이지 시작
        <div className="app-container">
            <header className="app-header">
                <img src={logo} alt="Logo" className="logo" />
                <div className="header-title">
                    <h1>관리자 페이지 ㅤㅤㅤ</h1>
                </div>
                <div>
                    <button onClick={handleLogout}>로그아웃</button>
                </div>
            </header>
            {/* 층 표시 */}
            <div className="main-content">
                <div className="tab-menu">
                    {/* Home 버튼 */}
                    <button
                        className={`tab-button ${activeTab === "home" ? "active" : ""}`}
                        onClick={() => setActiveTab("home")}
                    >
                        Home
                    </button>

                    {/* Floor 버튼 */}
                    <button
                        className={`tab-button ${activeTab === "floor" ? "active" : ""}`}
                        onClick={() => setIsFloorExpanded(!isFloorExpanded)}
                    >
                        각 층별 제어 화면
                    </button>

                    {/* Floor 버튼 클릭 시 하위 층 버튼 렌더링 */}
                    {isFloorExpanded &&
                        floors.map((floor) => (
                            <button
                                key={floor}
                                className={`tab-button ${activeTab === floor ? "active" : ""}`}
                                onClick={() => setActiveTab(floor)}
                            >
                                {floor}
                            </button>
                        ))}
                </div>

                {/* 홈 화면에 보여지는 차트 */}
                {activeTab === "home" && (
                    <div className="home-dashboard">
                        <div className="row">
                            {/* 사용 전력량 */}
                            <div className="home-item">
                                사용 전력량
                                <ReactECharts option={usageChartOptions} style={{ height: '200px', width: '100%' }} />
                            </div>
                            {/* 발전 전력량 */}
                            <div className="home-item">
                                <ReactECharts option={generationChartOptions} style={{ height: '200px', width: '100%' }} />
                            </div>
                            {/* 전력 효율 */}
                            <div className="home-item">
                                <div className="chart-container">
                                    <ReactECharts
                                        option={efficiencyChartOptions}
                                        style={{ height: '200px', width: '100%' }}
                                    />
                                </div>
                            </div>
                        </div>
                        {/* 날씨 */}
                        <div className="row">
                            <div className="home-item">
                                현재 날씨
                                <div className="weather-container">
                                    <div className="weather-card">
                                        <div className="weatherrow">
                                            <h2>{temp}°C</h2>
                                            <h3>{cloud}</h3>
                                        </div>
                                        <div className="weatherrow">
                                            <h4>습도: {humidity}%</h4>
                                            <h4>초속: {windspeed}m/s ({windpower})</h4>
                                            <h4>바람 방향: {winddeg}</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* 층별 온도, 습도 */}
                            <div className="home-item">
                                층별 온도, 습도
                                <ReactECharts option={temperatureChartOptions} style={{ height: '200px', width: '100%' }} />
                            </div>
                            {/* 현재 저장된 전력량 */}
                            <div className="home-item">
                                <ReactECharts option={essChartOptions} style={{ height: '200px', width: '100%' }} />
                            </div>
                        </div>
                    </div>
                )}


                {/* 층 별 구분 시작 */}
                {/* 1층 */}
                {activeTab === "1F" && (<Floor01/> )}
                {/* 2층 */}
                {activeTab === "2F" && (<Floor02/> )}
                {/* 3층 */}
                {activeTab === "3F" && (<Floor03/> )}
                {/* 4층 */}
                {activeTab === "4F" && (<Floor04/> )}
                {/* 5층 */}
                {activeTab === "5F" && (<Floor05/> )}
            </div>
	{/* 푸터 영역 */}
            <footer className="login-footer">
                <p>문의사항이 생기면 <a href="tel:01012345678">010-xxxx-vvvv</a>로 전화주세요.</p>
            </footer>
        </div>
    );
}

export default HomePage;
