import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; 
import "../style/Login.css"; // css 경로
import logo from "../img/sng2.png"; // 로고 경로
import axios from "axios";
import { userTimer, useTimer} from "../context/TimerContext"; 

const LoginPage = () => {
    const [admin_id, setAdmin_Id] = useState();
    const [admin_pw, setAdmin_Password] = useState();
    const navigate = useNavigate(); // navigate 객체
    const { startTimer } = useTimer(); // 타이머 시작

    const handleLogin = async (e) => {
        e.preventDefault();

        try {
            // 서버에 로그인 요청
            const response = await axios.post("ip 주소", { // ip 주소 입력
                admin_id,
                admin_pw,
            });

            if (response.status === 200) {
                // 로그인 성공 시 홈 페이지로 이동
                startTimer(); // 로그인 성공 시 타이머 시작
                navigate("/home");
            } else {
                // 로그인 실패 시
                alert("아이디나 비밀번호가 잘못되었습니다.");
            }
        } catch (error) {
            console.error("로그인 요청 중 오류 발생:", error);
            alert("로그인 중 문제가 발생했습니다. 다시 시도해주세요.");
        }
    };

    return (
        <div className="login-wrapper">
            {/* 헤더 영역 */}
            <header className="login-header">
                <img src={logo} alt="Logo" className="logo" />
                <div className="header-title">
                    <h1>귀요미 빌딩 관리자 ㅤㅤㅤ</h1>
                </div>
            </header>
            {/* 본문 영역 */}
            <div className="login-background">
                <div className="overlay">
                    <div className="login-container">
                        {/* ID 입력 */}
                        <form onSubmit={handleLogin}>
                            <input
                                type="text"
                                placeholder="ID를 입력하세요"
                                value={admin_id}
                                onChange={(e) => setAdmin_Id(e.target.value)}
                                required
                            />
                            {/* PW 입력 */}
                            <input
                                type="password"
                                placeholder="PW를 입력하세요"
                                value={admin_pw}
                                onChange={(e) => setAdmin_Password(e.target.value)}
                                required
                            />
                            <br />
                            <br />
                            <button type="submit">로그인</button>
                        </form>
                    </div>
                </div>
            </div>
            {/* 푸터 영역 */}
            <footer className="login-footer">
                <p>문의사항이 생기면 <a href="tel:01012345678">010-xxxx-vvvv</a>로 전화주세요.</p>
            </footer>
        </div>
    );
};

export default LoginPage;
